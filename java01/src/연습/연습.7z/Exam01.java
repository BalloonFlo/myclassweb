package 연습;

public class Exam01 {

	public static void main(String[] args) {
		//가로 110, 세로 220 입력 받아서 사각형의 면적을 구해 출력
		
		//입력
		int width = 110;
		int height = 220;
		
		//처리
		int square = width * height;
		
		//출력
		System.out.println("가로 110, 세로 220 사각형의 면적은 " + square +"입니다.");
	}

}

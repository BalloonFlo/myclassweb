package 연습;

public class 확인문제01 {

	public static void main(String[] args) {
		//1번 문제.
		char pw1 = 'p';
		char pw2 = 'q';
		if (pw1 == pw2) {
			System.out.println("PASS!");
		} else {
			System.out.println("재입력!");
		}
		
		//2번 문제.
		double change = 2.2;
		if (change > 2) {
			System.out.println("다이어트 성공!");
			
		//3번 문제.
		if (pw1 == pw2 && change > 2) {
			System.out.println("오늘은 성공!");
		} else {
			System.out.println("내일 다시 도전!");
		}
		//4번 문제.
		int a = 66;
		int m = 77;
		int i = 88;
		int k = 99;
		int add = a + m + i + k;
		double av = add / 4;
		System.out.println(av);
		
		//5번 문제.
		double p = 3.14;
		double r = 2.2;
		double result = p * r * r;
		System.out.println(result);
		}
	}

}
